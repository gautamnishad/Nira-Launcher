Simple Home - ek minimal, original Android launcher (koi ads/tracking/internet permission nahi)
Features: bada clock, favorites list, swipe-up se All apps, search, A-Z side bar,
long-press se favorites add/remove, App info.
